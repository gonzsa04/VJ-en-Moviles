package es.ucm.fdi.interfaces;

public interface ImageInterface {
    public int getWidth();
    public int getHeight();
}
