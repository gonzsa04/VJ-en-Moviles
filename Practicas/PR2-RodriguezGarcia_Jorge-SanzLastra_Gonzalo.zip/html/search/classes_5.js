var searchData=
[
  ['headerinfo_79',['HeaderInfo',['../struct_json_loader_1_1_header_info.html',1,'JsonLoader']]]
];
