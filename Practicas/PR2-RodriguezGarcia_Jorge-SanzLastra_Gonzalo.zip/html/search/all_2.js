var searchData=
[
  ['challengemanager_9',['ChallengeManager',['../class_challenge_manager.html',1,'']]]
];
