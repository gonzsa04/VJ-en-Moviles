var searchData=
[
  ['gamemanager_78',['GameManager',['../class_game_manager.html',1,'']]]
];
