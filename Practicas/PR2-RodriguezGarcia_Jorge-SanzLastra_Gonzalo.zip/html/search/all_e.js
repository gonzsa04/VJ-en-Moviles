var searchData=
[
  ['reset_40',['Reset',['../class_timer.html#a076af8892f86d50320215cfece9f2ab9',1,'Timer']]],
  ['resetgift_41',['ResetGift',['../class_menu_manager.html#a2d1384d90950ab0abd340de70d613421',1,'MenuManager']]],
  ['restartfrom_42',['RestartFrom',['../class_board_manager.html#af6ecd6d56c32193697fd21811a39a874',1,'BoardManager']]],
  ['restartlevel_43',['RestartLevel',['../class_game_manager.html#ae39cb7fa401b1814fdcac1a4207fbae2',1,'GameManager']]],
  ['rewardedads_44',['RewardedAds',['../class_rewarded_ads.html',1,'']]],
  ['rewardmethod_45',['RewardMethod',['../class_rewarded_ads.html#a41be2d0882576dd24944e16f5ed444eb',1,'RewardedAds']]]
];
