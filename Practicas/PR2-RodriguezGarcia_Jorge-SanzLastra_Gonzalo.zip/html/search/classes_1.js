var searchData=
[
  ['challengemanager_74',['ChallengeManager',['../class_challenge_manager.html',1,'']]]
];
