var searchData=
[
  ['jsonloader_24',['JsonLoader',['../class_json_loader.html',1,'JsonLoader'],['../class_json_loader.html#a6b6ec8050b25fe9845817bc30e025ef8',1,'JsonLoader.JsonLoader()']]]
];
