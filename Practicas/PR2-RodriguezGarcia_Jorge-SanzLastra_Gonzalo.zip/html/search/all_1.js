var searchData=
[
  ['backgroundfitter_6',['BackGroundFitter',['../class_back_ground_fitter.html',1,'']]],
  ['backtomenu_7',['BackToMenu',['../class_menu_manager.html#aae14135c337f0ffd8778521cbc7c484f',1,'MenuManager']]],
  ['boardmanager_8',['BoardManager',['../class_board_manager.html',1,'']]]
];
