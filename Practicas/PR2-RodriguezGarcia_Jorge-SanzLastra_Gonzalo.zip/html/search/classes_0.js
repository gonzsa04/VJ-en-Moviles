var searchData=
[
  ['backgroundfitter_72',['BackGroundFitter',['../class_back_ground_fitter.html',1,'']]],
  ['boardmanager_73',['BoardManager',['../class_board_manager.html',1,'']]]
];
