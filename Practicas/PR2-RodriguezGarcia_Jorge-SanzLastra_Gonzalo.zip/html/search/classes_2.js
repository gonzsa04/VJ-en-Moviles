var searchData=
[
  ['datamanager_75',['DataManager',['../class_data_manager.html',1,'']]],
  ['difficultyinfo_76',['DifficultyInfo',['../struct_data_manager_1_1_difficulty_info.html',1,'DataManager']]]
];
