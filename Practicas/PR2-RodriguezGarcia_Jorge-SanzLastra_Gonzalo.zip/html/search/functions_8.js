var searchData=
[
  ['payforchallenge_115',['PayForChallenge',['../class_menu_manager.html#a19f9e17e4c0d7864327884a60da1e277',1,'MenuManager']]]
];
