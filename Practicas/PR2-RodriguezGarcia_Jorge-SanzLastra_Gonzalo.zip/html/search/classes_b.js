var searchData=
[
  ['saveinfo_88',['SaveInfo',['../struct_json_loader_1_1_save_info.html',1,'JsonLoader']]],
  ['skin_89',['Skin',['../class_skin.html',1,'']]]
];
