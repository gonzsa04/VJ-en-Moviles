var searchData=
[
  ['reset_118',['Reset',['../class_timer.html#a076af8892f86d50320215cfece9f2ab9',1,'Timer']]],
  ['resetgift_119',['ResetGift',['../class_menu_manager.html#a2d1384d90950ab0abd340de70d613421',1,'MenuManager']]],
  ['restartfrom_120',['RestartFrom',['../class_board_manager.html#af6ecd6d56c32193697fd21811a39a874',1,'BoardManager']]],
  ['restartlevel_121',['RestartLevel',['../class_game_manager.html#ae39cb7fa401b1814fdcac1a4207fbae2',1,'GameManager']]],
  ['rewardmethod_122',['RewardMethod',['../class_rewarded_ads.html#a41be2d0882576dd24944e16f5ed444eb',1,'RewardedAds']]]
];
