var searchData=
[
  ['activatebiggift_93',['ActivateBigGift',['../class_menu_manager.html#ad0c444c630f489621becc97dd5aa6a40',1,'MenuManager']]],
  ['activategift_94',['ActivateGift',['../class_menu_manager.html#ab0995a564dabfec31c0a73fde883fa5c',1,'MenuManager']]],
  ['activatereward_95',['ActivateReward',['../class_menu_manager.html#a83866ec6cb83f0f7b4b79bdca9df53d6',1,'MenuManager']]],
  ['addhint_96',['AddHint',['../class_tile.html#a1d4bde016385a03fec2902c43eb123ab',1,'Tile']]],
  ['addpath_97',['AddPath',['../class_tile.html#ae834639a3cd70d95d2e9d77c70b1ec75',1,'Tile']]],
  ['allhintsgiven_98',['AllHintsGiven',['../class_board_manager.html#a680760bcb17d2c09a17c15a2a5a56cb3',1,'BoardManager']]]
];
